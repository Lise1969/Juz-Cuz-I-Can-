jQuery(document).ready(function () {
    // // Handler for .ready() called.
    jQuery('html, body').animate({
        scrollTop: jQuery('#scroll-top').offset().top
    }, 'slow');

  });

