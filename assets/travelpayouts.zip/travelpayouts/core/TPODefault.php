<?php
/**
 * Created by PhpStorm.
 * User: freeman
 * Date: 07.08.15
 * Time: 0:41
 */
namespace core;
interface TPODefault {
    public static function defaultOptions();
}