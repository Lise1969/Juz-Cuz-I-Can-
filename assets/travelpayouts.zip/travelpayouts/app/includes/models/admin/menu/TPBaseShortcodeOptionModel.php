<?php
/**
 * Created by PhpStorm.
 * User: romansolomashenko
 * Date: 30.01.17
 * Time: 11:03 AM
 */

namespace app\includes\models\admin\menu;


use app\includes\models\admin\TPOptionModel;

abstract class TPBaseShortcodeOptionModel extends TPOptionModel
{

}