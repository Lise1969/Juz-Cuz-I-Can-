<div id="adminNoticeModal" class="notice" style="display: none;">
    <!--<p></p>
    <button type="button" class="notice-dismiss"></button>-->
    <p><?php _ex('Settings saved.','tp admin page admin notice modal label', TPOPlUGIN_TEXTDOMAIN ); ?></p>
    <button class="TPnotice-dismiss" id="adminNoticeModalClose"></button>
</div>