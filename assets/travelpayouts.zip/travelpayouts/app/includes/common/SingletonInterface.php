<?php
/**
 * Created by PhpStorm.
 * User: romansolomashenko
 * Date: 10.01.17
 * Time: 1:53 PM
 */

namespace app\includes\common;


interface SingletonInterface
{
    public static function getInstance();
}